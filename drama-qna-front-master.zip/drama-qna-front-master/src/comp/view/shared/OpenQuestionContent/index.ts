
export { default } from './OpenQuestionContentView';
