
export { default } from './QuestionContentView';
