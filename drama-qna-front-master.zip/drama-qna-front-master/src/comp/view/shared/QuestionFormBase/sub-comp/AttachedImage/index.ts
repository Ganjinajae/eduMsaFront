
export { default } from './AttachedImageView';
