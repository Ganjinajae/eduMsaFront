
import configureManager from '@nara.platform/storybook/storyConfig/configureManager';

configureManager();
