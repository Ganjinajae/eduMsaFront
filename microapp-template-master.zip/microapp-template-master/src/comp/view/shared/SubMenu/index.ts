
export { default } from './SubMenuView';
