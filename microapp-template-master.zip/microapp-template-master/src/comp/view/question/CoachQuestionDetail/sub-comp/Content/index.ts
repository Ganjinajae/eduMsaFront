
export { default } from './ContentView';
