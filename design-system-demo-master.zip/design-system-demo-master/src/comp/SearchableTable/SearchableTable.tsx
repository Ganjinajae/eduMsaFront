import React from 'react';
import SearchBox from '../SearchBox/SearchBox';
import {Table, TableBody, TableCell, TableHead, TableRow} from '@material-ui/core';

export interface SearchableTableProps {
    data: any[];                 // [{ key: '1', value: 'one'}, { key: '2', value: 'two'}, { key: '3', value: 'three'}]
    colNames: string[];             // [ "key", "value" ]
    filterKeyName: string;          // "key"
}

interface State {
    keyword: string;
}

class SearchableTable extends React.Component<SearchableTableProps, State> {

    state: State = {
        keyword: ''
    };

    constructor(props: SearchableTableProps) {
        super(props);
        this.onClickSearch = this.onClickSearch.bind(this);
    }

    onClickSearch(keyword: string) {
        this.setState({keyword: keyword});
    }

    render() {
        const { data, colNames, filterKeyName } = this.props;
        const { keyword } = this.state;

        return (
            <div>
                <SearchBox onClickSearch={this.onClickSearch}/>
                <Table>
                    <TableHead>
                        <TableRow>
                            {
                                colNames.map(colName => (
                                    <TableCell>{colName}</TableCell>
                                ))
                            }
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                            data.filter(element => element[filterKeyName].includes(keyword))
                                .map(element => (
                                    <TableRow>
                                        {
                                            colNames.map(colName => (
                                                <TableCell>{element[colName]}</TableCell>
                                            ))
                                        }
                                    </TableRow>
                                ))
                        }
                    </TableBody>
                </Table>
            </div>
        );
    }
}
export default SearchableTable;
