export { default } from './ReactComponent';
