import {makeObservable, observable} from 'mobx';
import Profile from '../model';

class ProfileStateKeeper {
    //
    static instance: ProfileStateKeeper;

    profile: Profile = new Profile();
    profileList: Profile[] = [];

    constructor() {
        //
        makeObservable(this, {
            profile: observable,
            profileList: observable,
        })
    }

    setProfile(name: keyof Profile, value: string): void {
        //
        const newProfile = {...this.profile};
        newProfile[name] = value;

        this.profile = newProfile;
    }

    addProfile(): void {
        //
        const newProfileList = [...this.profileList];
        newProfileList.push(this.profile);

        this.profileList = newProfileList;
        this.profile = new Profile();
    }

    removeProfile(selectedIndex: number): void {
        //
        const newProfileList = this.profileList.filter(
            (profile: Profile, index: number) => index !== selectedIndex
        );

        this.profileList = newProfileList;
    }

    attend(selectedIndex: number): void {
        //
        const newProfileList = [...this.profileList];
        newProfileList[selectedIndex].attendance = '출석하기';

        this.profileList = newProfileList;
    }
}

ProfileStateKeeper.instance = new ProfileStateKeeper();
export default ProfileStateKeeper;
