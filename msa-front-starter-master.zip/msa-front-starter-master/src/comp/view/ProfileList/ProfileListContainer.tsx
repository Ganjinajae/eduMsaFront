import React from 'react';
import { observer, inject } from 'mobx-react';
import Profile from '../../model';
import ProfileListView from './view/ProfileListView';
import autobind from 'autobind-decorator';
import ProfileStateKeeper from '../../state/ProfileStateKeeper';
import ReactComponent from '../../shared/ReactComponent';

interface Props {
    initialText?: string;
}

interface State {

}

interface InjectedProps {
    //
    profileStateKeeper: ProfileStateKeeper;
}

@inject('profileStateKeeper')
@autobind
@observer
class ProfileListContainer extends ReactComponent<Props, State, InjectedProps> {
    //
    onChangeProfile(name: keyof Profile, value: string): void {
        //
        const { profileStateKeeper } = this.injected;

        profileStateKeeper.setProfile(name, value);
    }

    onAdd() {
        //
        const { profileStateKeeper } = this.injected;

        profileStateKeeper.addProfile();
    }

    onRemove(selectedIndex: number) {
        //
        const { profileStateKeeper } = this.injected;

        profileStateKeeper.removeProfile(selectedIndex);
    }

    onAttend(selectedIndex: number): void {
        //
        const { profileStateKeeper } = this.injected;

        profileStateKeeper.attend(selectedIndex);
    }

    render() {
        //
        const { profile, profileList } = this.injected.profileStateKeeper;

        return (
            <ProfileListView
                profile={profile}
                profileList={profileList}
                onAdd={this.onAdd}
                onRemove={this.onRemove}
                onChangeProfile={this.onChangeProfile}
                onAttend={this.onAttend}
            />
        )
    }
}

export default ProfileListContainer;
