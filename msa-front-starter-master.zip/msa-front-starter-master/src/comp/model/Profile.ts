class Profile {
    name: string = '';
    email: string = '';
    age: string = '';
    attendance: string = '-';

    constructor(profile?: Profile) {
        if (profile) {
            Object.assign(this, profile);
        }
    }
}

export default Profile;
