import React from 'react';
import { ProfileList } from '../comp';

class MainPage extends React.Component {
    //
    render() {
        return (
            <ProfileList />
        )
    }
}

export default MainPage;
