import React from 'react';
import { Provider } from 'mobx-react';
import './App.css';
import MainPage from './page/MainPage';
import ProfileStateKeeper from './comp/state/ProfileStateKeeper';

function App() {
  return (
      <Provider profileStateKeeper={ProfileStateKeeper.instance}>
        <MainPage />
      </Provider>
  );
}

export default App;
